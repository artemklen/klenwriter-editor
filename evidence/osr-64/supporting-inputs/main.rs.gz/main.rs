use editor_core::candidate::{BorrowedNode, CandidateRead};
use editor_core::document::{Document, Node};
use editor_core::profile::{AdmissionMode, FrozenProfile};
use editor_core::transaction::{WorkLimits, WorkMeter, WorkPhase, WorkUsage};
use editor_kwdj::{AdmissionBudget, IdentityResolver, IdentityResolverError, IdentityStatus, KwdjProfile, KwdjProfileError, Limits};
use serde_json::{Value,json};
use std::time::Instant;
use uuid::Uuid;

struct Facts;
impl IdentityResolver for Facts {
 fn resolve_media(&self,_:&Uuid)->Result<IdentityStatus,IdentityResolverError>{Ok(IdentityStatus::Missing)}
 fn resolve_reference(&self,_:&Uuid)->Result<IdentityStatus,IdentityResolverError>{Ok(IdentityStatus::Missing)}
}
// Same three-u64 / align8 layout as the actual engine NodeId; no handles escape.
#[derive(Clone,Copy,PartialEq,Eq,PartialOrd,Ord)]
struct Id([u64;3]);
struct Record<'a>{node:&'a Node,parent:Id,children:Vec<Id>}
struct View<'a>{roots:Vec<Id>,nodes:Vec<Record<'a>>}
impl<'a> View<'a>{
 fn new(doc:&'a Document)->Self {let mut v=Self{roots:Vec::new(),nodes:Vec::new()};for node in &doc.children{let id=v.add(node,Id([1,1,1]));v.roots.push(id);}v}
 fn add(&mut self,node:&'a Node,parent:Id)->Id{let i=self.nodes.len();let id=Id([1,1,i as u64+2]);self.nodes.push(Record{node,parent,children:vec![]});let children=node.children.iter().map(|child|self.add(child,id)).collect();self.nodes[i].children=children;id}
}
impl CandidateRead for View<'_>{
 type Id=Id;
 fn root(&self)->Id{Id([1,1,1])}
 fn roots(&self)->&[Id]{&self.roots}
 fn node(&self,id:Id)->Option<BorrowedNode<'_,Id>>{if id==self.root(){return None;}let r=self.nodes.get((id.0[2].checked_sub(2)?) as usize)?;let n=r.node;Some(BorrowedNode{type_id:&n.type_id,primitive:n.primitive,attributes:&n.attributes,marks:&n.marks,text:n.text.as_deref(),children:&r.children,parent:r.parent})}
}
fn usage(v:WorkUsage)->Value{json!({"units":v.units,"bytes":v.bytes})}
fn phases(w:&WorkMeter)->Value{let mut m=serde_json::Map::new();for p in [WorkPhase::Structure,WorkPhase::Header,WorkPhase::Preflight,WorkPhase::Normalization,WorkPhase::Serialization,WorkPhase::StaticValidation,WorkPhase::Identity,WorkPhase::CacheReuse,WorkPhase::CacheUpdate,WorkPhase::Impact,WorkPhase::Event,WorkPhase::Export,WorkPhase::FullFallback]{let v=w.trace().phase(p);m.insert(format!("{p:?}"),json!({"visits":v.visits,"bytes":v.bytes}));}Value::Object(m)}
fn err(e:KwdjProfileError)->Value{match e{KwdjProfileError::Binding(e)=>json!({"code":e.as_str(),"debug":format!("{e:?}")}),KwdjProfileError::Document(e)=>json!({"code":e.code.as_str(),"debug":format!("{e:?}")}),KwdjProfileError::Registry(e)=>json!({"code":e.code.as_str(),"path":e.path,"detail":e.detail,"local_work":usage(e.usage.work)})}}
fn main(){let mut out=vec![];for count in [49_999usize,50_000]{let input=std::fs::read(format!("/tmp/osr-64-cache-seed-measure/inputs/{count}.json")).unwrap();let profile=KwdjProfile::new(&Facts,Limits::default(),AdmissionBudget::default());let admitted=profile.admit_bytes(profile.binding(),&input,AdmissionMode::Strict).unwrap();let doc=profile.to_document(&admitted);let view=View::new(&doc);assert_eq!(view.nodes.len(),count);
 let mut default=WorkMeter::new(WorkLimits::default());let t=Instant::now();let default_result=profile.seed_cache(&admitted,&view,&mut default);let default_time=t.elapsed().as_nanos().to_string();let default_error=default_result.err().map(err);
 let mut combined=WorkMeter::new(WorkLimits{units:20_000_000,bytes:512*1024*1024});let t=Instant::now();let result=profile.seed_cache(&admitted,&view,&mut combined);let combined_time=t.elapsed().as_nanos().to_string();let accepted=result.is_ok();let combined_error=result.err().map(err);
 let mut schema=WorkMeter::new(WorkLimits{units:20_000_000,bytes:512*1024*1024});let t=Instant::now();let proof=profile.registry().validate_full(&view,&mut schema).unwrap();let schema_time=t.elapsed().as_nanos().to_string();let stats=json!({"metadata_visits":proof.usage.metadata_visits,"grammar_visits":proof.usage.grammar_visits,"reused_nodes":proof.usage.reused_nodes});
 let domain=if accepted{Some(WorkUsage{units:combined.usage().units-schema.usage().units,bytes:combined.usage().bytes-schema.usage().bytes})}else{None};
 out.push(json!({"authored_nodes":count,"input_bytes":input.len(),"canonical_bytes":profile.canonical(&admitted).len(),"roots":view.roots.len(),"id_bytes":std::mem::size_of::<Id>(),"id_alignment":std::mem::align_of::<Id>(),"strict_admission":"accepted","default_seed":{"accepted":default_error.is_none(),"error":default_error,"work":usage(default.usage()),"phases":phases(&default),"observed_ns":default_time},"private_large_meter_seed":{"accepted":accepted,"error":combined_error,"work":usage(combined.usage()),"effective_limits":{"units":combined.limits().units,"bytes":combined.limits().bytes},"phases":phases(&combined),"observed_ns":combined_time},"schema_alone":{"work":usage(schema.usage()),"phases":phases(&schema),"visits":stats,"observed_ns":schema_time},"derived_domain_seed_work":domain.map(usage)}));}
 println!("{}",serde_json::to_string_pretty(&json!({"scope":"Private observational ceiling only; production Default/transaction/compiler caps unchanged. Exact current public KwdjProfile strict admitted documents + borrowed CandidateRead, three-u64 IDs matching NodeId layout. Derived domain cost = completed composite minus identical standalone schema.","cases":out})).unwrap());}
