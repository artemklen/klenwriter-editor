#[path = "identity.source.rs"]
mod identity;
#[derive(Clone,Copy)]
struct Id([u64;3]);
fn main(){println!("{{\"engine_node_id_bytes\":{},\"engine_node_id_alignment\":{},\"engine_option_node_id_bytes\":{},\"measurement_id_bytes\":{},\"measurement_id_alignment\":{},\"measurement_option_id_bytes\":{}}}",std::mem::size_of::<identity::NodeId>(),std::mem::align_of::<identity::NodeId>(),std::mem::size_of::<Option<identity::NodeId>>(),std::mem::size_of::<Id>(),std::mem::align_of::<Id>(),std::mem::size_of::<Option<Id>>());}
