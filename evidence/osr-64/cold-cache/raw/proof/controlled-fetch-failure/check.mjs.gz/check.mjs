
import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';import {createHash} from 'node:crypto';import {buildExtensionConsumers} from './scripts/build-extensions-consumers.mjs';
const source=readFileSync('scripts/build-extensions-consumers.mjs');let failure;
try {await buildExtensionConsumers({baseBuildId:'sha256:'+'0'.repeat(64),baseSourceHashes:{'scripts/build-extensions-consumers.mjs':createHash('sha256').update(source).digest('hex')}});} catch(error){failure=error;}
assert(failure);assert.match(failure.message,/External consumer fetch-locked failed \(exit 42/);
const d=JSON.parse(readFileSync('artifacts/extensions/consumers/notes-only/build.json'));
assert.equal(d.status,'failed');assert.deepEqual(d.commands.map(x=>x.label),['rust-toolchain','bindgen-toolchain','fetch-locked']);assert.equal(d.commands.at(-1).exitCode,42);
assert.equal(readFileSync(d.commands.at(-1).stderr.path,'utf8'),'controlled-fetch-failure\n');
const index=JSON.parse(readFileSync('artifacts/extensions/consumers/builds.json'));assert.equal(index.status,'failed');assert.equal(index.failedVariant,'notes-only');
process.stdout.write(JSON.stringify({controlled:true,sourceSha256:createHash('sha256').update(source).digest('hex'),commandLabels:d.commands.map(x=>x.label),fetchExitCode:d.commands.at(-1).exitCode,noOfflineGraphOrBuildExecuted:true,indexStatus:index.status})+'\n');
